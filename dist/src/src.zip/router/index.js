import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '@/pages/home/home'
import AboutUs from '@/pages/about-us/about-us'
import ContactUs from '@/pages/contact-us/contact-us'
import CosmeticServices from '@/pages/cosmetic-services/cosmetic-services'
import MissingTeeth from '@/pages/missing-teeth/missing-teeth'
import OtherServices from '@/pages/other-services/other-services'

import PageNotFound from '@/pages/404/404'

Vue.use(VueRouter)

const router = new VueRouter({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'Home',
      navigation: true,
      component: Home
    },
    {
      path: '/about-us',
      name: 'About us',
      navigation: true,
      component: AboutUs
    }, {
      path: '/cosmetic-services',
      name: 'Cosmetic Services',
      navigation: true,
      component: CosmeticServices
    }, {
      path: '/missing-teeth',
      name: 'Missing teeth',
      navigation: true,
      component: MissingTeeth
    }, {
      path: '/other-services',
      name: 'Other services',
      navigation: true,
      component: OtherServices
    }, {
      path: '/contact-us',
      name: 'Contact us',
      navigation: true,
      component: ContactUs
    }, {
      path: '/*',
      name: 'page-not-found',
      navigation: false,
      component: PageNotFound
    }
  ]
})

router.beforeEach((to, from, next) => {
  window.scrollTo(0, 0)
  next()
})

export default router
