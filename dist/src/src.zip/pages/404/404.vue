<template lang='pug' src='./404.pug'></template>
