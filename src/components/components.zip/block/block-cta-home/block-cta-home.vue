<template lang="pug" src="./block-cta-home.pug">
</template>

<script>
export default {
  props: ['props']
}
</script>
