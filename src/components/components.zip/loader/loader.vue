<template lang='pug' src='./loader.pug'></template>
